# Metadata da Ingestão
## Objetivo
Registrar arquivos, status e contexto do tenant.
## Escopo
Tabela e fluxo inicial de metadata.
## Fora de escopo
Catálogo final completo.
## Impacto técnico
Backend data, banco.
## Subtarefas
- tabela de uploads
- status iniciais
- file type
- file size
- vínculo com tenant
## Critérios de aceite
Todo upload gera metadata persistida.
## Riscos
Metadados incompletos.
## Dependências
File upload.
