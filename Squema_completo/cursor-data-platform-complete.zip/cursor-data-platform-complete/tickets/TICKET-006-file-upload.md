# Upload de Arquivos
## Objetivo
Permitir upload inicial de CSV, TXT, XLS, XLSX e JSON.
## Escopo
Upload e armazenamento físico.
## Fora de escopo
Parsing completo.
## Impacto técnico
Backend data, frontend, segurança.
## Subtarefas
- endpoint upload
- validação de tipo
- validação de tamanho
- persistência física
- tela de upload
## Critérios de aceite
Arquivo válido é recebido e armazenado.
## Riscos
Upload de arquivo inválido ou muito grande.
## Dependências
Tenant foundation.
