# Roadmap

## Fase 1
- auth
- tenant
- usuários
- grupos
- upload básico
- catálogo básico

## Fase 2
- pipeline assíncrona
- billing
- limites por plano
- admin

## Fase 3
- dashboards básicos
- customização por tenant
- auditoria avançada
- observabilidade
