# Arquitetura

## Blocos
- Web App
- API
- Worker de ingestão
- PostgreSQL
- Redis
- Armazenamento de arquivos

## Domínios principais
- Identity & Access
- Tenancy
- Billing
- File Upload
- Ingestion
- Dataset Catalog
- Workspace
- Admin

## Regra central
Nada cruza tenant sem autorização explícita e validada no backend.
