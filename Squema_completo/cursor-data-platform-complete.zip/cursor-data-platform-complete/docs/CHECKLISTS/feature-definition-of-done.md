# Definition of Done
- objetivo atendido
- regras de negócio respeitadas
- tratamento de erro implementado
- logs mínimos incluídos
- testes mínimos criados
- documentação mínima atualizada
