# Cursor Data Platform Complete

Pacote pronto para abrir no Cursor e usar como base de uma plataforma SaaS multitenant de dados.

## Como usar
1. Extraia este pacote em uma pasta.
2. Abra a pasta no Cursor.
3. Leia o arquivo `PROMPT_CURSOR.md`.
4. Cole o prompt no chat do Cursor para iniciar.

## Estrutura principal
- `.cursor/rules`: regras globais e por domínio
- `.cursor/agents`: papéis dos agentes
- `.cursor/skills`: skills reutilizáveis
- `.cursor/hooks`: scripts auxiliares
- `docs/`: visão, arquitetura, roadmap, backlog e checklists
- `tickets/`: tickets iniciais do MVP
- `apps/`, `packages/`, `infra/`: base do monorepo
