# Shared

Utilitários compartilhados entre apps.
