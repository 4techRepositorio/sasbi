# Contracts

Schemas, DTOs e contratos compartilhados.
