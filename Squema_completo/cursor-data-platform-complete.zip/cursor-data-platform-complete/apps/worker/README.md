# Worker

Espaço reservado para jobs assíncronos de ingestão.
