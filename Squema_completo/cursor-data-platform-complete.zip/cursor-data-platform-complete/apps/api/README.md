# API

Espaço reservado para o backend principal.
Stack sugerida:
- FastAPI
- SQLAlchemy
- Alembic
- PostgreSQL
- Redis
