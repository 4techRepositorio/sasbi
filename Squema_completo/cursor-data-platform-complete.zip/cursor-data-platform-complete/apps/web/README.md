# Web

Espaço reservado para o frontend.
Stack sugerida:
- Angular
- TypeScript
- PWA
